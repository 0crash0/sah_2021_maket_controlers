from setuptools import setup

setup(
    name = 'TroykaCapPython',
    version = '1.0',
    description = 'TroykaCapPython',
    author = 'acosinwork',
    author_email = 'vasily@amperka.ru',
    url = 'amperka.ru',
    py_modules=['gpioexp'],
)
